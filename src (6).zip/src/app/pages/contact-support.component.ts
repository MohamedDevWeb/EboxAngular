import { Component, OnInit, inject, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { ContactSupportService, ContactFormData } from '../services/contact-support.service';

interface FaqItem {
  question: string;
  answer: string;
  open?: boolean;
}

@Component({
  selector: 'app-contact-support',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatIconModule,
    MatButtonModule,
    MatCardModule,
    MatTooltipModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatProgressSpinnerModule
  ],
  templateUrl: './contact-support.component.html',
  styleUrls: ['./contact-support.component.scss']
})
export class ContactSupportComponent implements OnInit {
  @ViewChild('fileUpload') fileUpload!: ElementRef<HTMLInputElement>;
  @ViewChild('contactForm') contactForm!: NgForm;

  // Formulaire
  form: ContactFormData = {
    nom: '',
    email: '',
    telephone: '',
    sujet: '',
    message: '',
    file: undefined,
    consent: false
  };
  sujetOptions = [
    'Assistance technique',
    'Questions médicales',
    'Problème de connexion',
    'Demande de document',
    'Autre'
  ];
  loading = false;
  sent = false;
  error = '';
  fileName = '';

  // FAQ (exemple, adapte selon besoins)
  faq: FaqItem[] = [
    {
      question: 'Comment obtenir un duplicata de document médical ?',
      answer: 'Connectez-vous à votre espace, puis rendez-vous dans la rubrique "Mes documents" pour télécharger ou demander un duplicata.',
      open: false
    },
    {
      question: 'Comment prendre rendez-vous avec un médecin partenaire ?',
      answer: 'Allez dans la page "Prendre RDV" et choisissez le médecin ou le service concerné.',
      open: false
    },
    {
      question: 'Que faire en cas de perte d’accès à mon compte ?',
      answer: 'Utilisez la procédure de récupération sur la page de connexion ou contactez notre support par téléphone.',
      open: false
    },
    {
      question: 'Est-ce que mes données sont protégées ?',
      answer: 'Oui, notre plateforme est conforme RGPD et sécurisée par chiffrement de bout en bout.',
      open: false
    },
    {
      question: 'Puis-je envoyer mes questions par email ?',
      answer: 'Oui, notre support traite toutes les demandes envoyées via le formulaire ou directement par email.',
      open: false
    }
  ];

  // Contact rapide
  horaires = [
    { jours: 'Lundi - Vendredi', heures: '08:00 – 20:00' },
    { jours: 'Samedi', heures: '09:00 – 13:00' }
  ];

  private contactService: ContactSupportService = inject(ContactSupportService);

  ngOnInit() {
    // reset form visuel si reload
    this.resetForm();
  }

  uploadTrigger() {
    this.fileUpload.nativeElement.click();
  }

  onFileSelected(event: Event) {
    const file = (event.target as HTMLInputElement).files?.[0];
    this.form.file = file;
    this.fileName = file ? file.name : '';
  }

  toggleFaq(i: number) {
    this.faq[i].open = !this.faq[i].open;
  }

  resetForm() {
    this.form = {
      nom: '',
      email: '',
      telephone: '',
      sujet: '',
      message: '',
      file: undefined,
      consent: false
    };
    this.fileName = '';
    this.sent = false;
    this.error = '';
    if (this.contactForm) this.contactForm.resetForm();
  }

  submitForm() {
    this.loading = true;
    this.error = '';
    this.sent = false;

    // Simule validation lourde + envoi backend
    setTimeout(() => {
      if (!this.form.nom.trim() || !this.form.email.trim() || !this.form.sujet.trim() || !this.form.message.trim()) {
        this.error = "Merci de remplir tous les champs obligatoires.";
        this.loading = false;
        return;
      }
      if (!this.form.consent) {
        this.error = "Merci d'accepter la politique de confidentialité.";
        this.loading = false;
        return;
      }
      // Simuler appel API ici
      this.contactService.sendForm(this.form).subscribe({
        next: () => {
          this.loading = false;
          this.sent = true;
          this.resetForm();
        },
        error: () => {
          this.error = "Erreur lors de l'envoi. Veuillez réessayer.";
          this.loading = false;
        }
      });
    }, 1200);
  }

  // Simule un chat live support
  openLiveChat() {
    alert('Un conseiller va vous répondre (simulation live chat).');
  }

  openMap() {
    window.open('https://maps.google.com/?q=Centre+Médical+Santé+Plus+Bruxelles', '_blank');
  }
}
