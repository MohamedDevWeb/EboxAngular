import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatCardModule } from '@angular/material/card';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatInputModule } from '@angular/material/input';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatFormFieldModule } from '@angular/material/form-field';
import { PrendreRdvService, RdvItem, Medecin } from '../services/prendre-rdv.service';

@Component({
  selector: 'app-prendre-rdv',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatIconModule,
    MatButtonModule,
    MatCardModule,
    MatSelectModule,
    MatDatepickerModule,
    MatInputModule,
    MatTooltipModule,
    MatFormFieldModule
  ],
  templateUrl: './prendre-rdv.component.html',
  styleUrls: ['./prendre-rdv.component.scss']
})
export class PrendreRdvComponent implements OnInit {
  medecins: Medecin[] = [];
  motif = '';
  medecin?: Medecin;
  date: Date | null = null;
  heure = '';
  loading = false;
  message = '';
  private rdvService: PrendreRdvService = inject(PrendreRdvService);

  ngOnInit() {
    this.rdvService.getMedecins().subscribe((ms: Medecin[]) => this.medecins = ms);
  }

  submit() {
    if (!this.motif || !this.medecin || !this.date || !this.heure) {
      this.message = "Veuillez remplir tous les champs.";
      return;
    }
    this.loading = true;
    this.rdvService.prendreRdv({
      motif: this.motif,
      medecin: this.medecin.nom,
      date: this.date,
      heure: this.heure,
      status: 'En attente'
    }).subscribe(() => {
      this.message = "✅ Rendez-vous enregistré ! Un email de confirmation vous sera envoyé.";
      this.loading = false;
      this.motif = '';
      this.medecin = undefined;
      this.date = null;
      this.heure = '';
    });
  }
}
