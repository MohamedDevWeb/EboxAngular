import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { Router } from '@angular/router';
import { TranslateModule, TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    TranslateModule
  ],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  loading = false;
  lang = 'fr';

  constructor(
    private router: Router,
    private translate: TranslateService
  ) {
    this.lang = translate.currentLang || translate.defaultLang || 'fr';
    translate.onLangChange.subscribe(e => { this.lang = e.lang; });
  }

  loginItsme() {
    this.loading = true;
    setTimeout(() => {
      this.loading = false;
      this.router.navigate(['/accueil']);
    }, 1800);
  }
}
