import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-redirect',
  standalone: true,
  templateUrl: './login-redirect.component.html',
  styleUrls: ['./login-redirect.component.scss']
})
export class LoginRedirectComponent {
  constructor(private router: Router) {
    setTimeout(() => this.router.navigate(['/login-auth']), 1200);
  }
}
