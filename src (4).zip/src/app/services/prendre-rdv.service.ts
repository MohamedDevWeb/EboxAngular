import { Injectable } from '@angular/core';
import { Observable, of, delay } from 'rxjs';

export interface Medecin {
  nom: string;
  specialite: string;
}
export interface RdvItem {
  motif: string;
  medecin: string;
  date: Date;
  heure: string;
  status: string;
}

@Injectable({ providedIn: 'root' })
export class PrendreRdvService {
  private medecins: Medecin[] = [
    { nom: 'Dr Alain Martin', specialite: 'Généraliste' },
    { nom: 'Dr Sophie Durand', specialite: 'Cardiologue' },
    { nom: 'Dr Luc Petit', specialite: 'Radiologue' },
    { nom: 'Dr Amira Ben', specialite: 'Pédiatre' },
    { nom: 'Dr Julie Leroy', specialite: 'Gynécologue' }
  ];

  getMedecins(): Observable<Medecin[]> {
    return of(this.medecins).pipe(delay(350));
  }

  prendreRdv(item: RdvItem): Observable<boolean> {
    // Simulation API
    return of(true).pipe(delay(1000));
  }
}
