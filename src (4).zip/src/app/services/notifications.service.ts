import { Injectable } from '@angular/core';
import { Observable, of, delay } from 'rxjs';

export interface NotificationItem {
  id: number;
  titre: string;
  message: string;
  date: string;
  type: 'info' | 'urgent' | 'rappel' | 'partage';
  lu: boolean;
  archive?: boolean;
  lien?: string;
}

@Injectable({ providedIn: 'root' })
export class NotificationsService {
  private notifs: NotificationItem[] = [
    {
      id: 1,
      titre: 'Document partagé',
      message: 'Votre médecin a partagé une nouvelle analyse sanguine.',
      date: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
      type: 'partage',
      lu: false,
      lien: '/assets/Analyse_sang_2024.pdf'
    },
    {
      id: 2,
      titre: 'Rappel : Rendez-vous demain',
      message: 'Vous avez un rendez-vous demain à 14h avec Dr. Martin.',
      date: new Date(Date.now() - 26 * 60 * 60 * 1000).toISOString(),
      type: 'rappel',
      lu: false
    },
    {
      id: 3,
      titre: 'Urgence : résultat critique',
      message: 'Un résultat d\'analyse nécessite une attention immédiate.',
      date: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
      type: 'urgent',
      lu: true
    },
    {
      id: 4,
      titre: 'Nouvelle information',
      message: 'Découvrez la nouvelle interface eBox Santé+ disponible dès aujourd’hui !',
      date: new Date(Date.now() - 12 * 24 * 60 * 60 * 1000).toISOString(),
      type: 'info',
      lu: true
    }
  ];

  getAll(): Observable<NotificationItem[]> {
    // Simule un appel API
    return of([...this.notifs]).pipe(delay(650));
  }
}
