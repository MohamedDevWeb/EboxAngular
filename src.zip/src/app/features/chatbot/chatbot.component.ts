import { Component, Inject, LOCALE_ID } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';

interface ChatMessage {
  text: string;
  author: 'user' | 'bot';
  timestamp: Date;
}

@Component({
  selector: 'app-chatbot',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatIconModule,
    MatButtonModule
  ],
  templateUrl: './chatbot.component.html',
  styleUrls: ['./chatbot.component.scss']
})
export class ChatbotComponent {
  messages: ChatMessage[] = [
    {
      text: this.isFr() ?
        "👋 Bonjour ! Je suis l’assistant IA d’eBox Santé+. Je peux vous aider sur tous les services : documents, analyses, rendez-vous, notifications, partage, guide santé… Posez-moi votre question !" :
        "👋 Hallo! Ik ben de eBox Santé+ assistent. Ik help je met documenten, analyses, afspraken, meldingen, delen, gezondheidsadvies... Stel gerust je vraag!",
      author: 'bot',
      timestamp: new Date()
    }
  ];
  input = '';
  sending = false;

  constructor(@Inject(LOCALE_ID) public locale: string) {}

  isFr(): boolean {
    return this.locale.startsWith('fr');
  }

  async sendMessage() {
    if (!this.input.trim()) return;
    const text = this.input;
    this.messages.push({ text, author: 'user', timestamp: new Date() });
    this.input = '';
    this.sending = true;

    setTimeout(() => {
      const aiResponse = this.isFr()
        ? this.getContextualResponseFr(text)
        : this.getContextualResponseNl(text);
      this.messages.push({
        text: aiResponse,
        author: 'bot',
        timestamp: new Date()
      });
      this.sending = false;
      setTimeout(() => this.scrollToBottom(), 10);
    }, 700);
  }

  // Version FR
  getContextualResponseFr(userText: string): string {
    const lower = userText.toLowerCase();

    if (lower.includes('bonjour') || lower.includes('salut'))
      return "Bonjour ! Comment puis-je vous accompagner aujourd’hui sur eBox Santé+ ?";
    if (lower.includes('rdv') || lower.includes('rendez-vous'))
      return "Pour prendre un rendez-vous médical, cliquez sur « Prendre RDV » dans le menu à gauche. Sélectionnez le type, la date et l'heure.";
    if (lower.includes('document') || lower.includes('pdf') || lower.includes('fichier'))
      return "Retrouvez tous vos documents médicaux dans « Mes Documents ». Vous pouvez visualiser, télécharger, partager ou importer un nouveau document.";
    if (lower.includes('analyse') || lower.includes('examen') || lower.includes('résultat'))
      return "Vos résultats d’analyses et d’examens sont dans « Analyses & Examens ». Cliquez dessus pour plus de détails ou pour les télécharger en PDF.";
    if (lower.includes('notification') || lower.includes('alerte'))
      return "Consultez vos notifications via l’icône de cloche ou la page « Notifications ». Vous y trouverez nouveaux documents, rappels, etc.";
    if (lower.includes('partage') || lower.includes('partager') || lower.includes('envoyer'))
      return "Pour partager un document, rendez-vous dans « Mes Documents », ouvrez le document et cliquez sur « Partager ». Vous pouvez aussi utiliser « Documents Partagés ».";
    if (lower.includes('guide') || lower.includes('infos santé') || lower.includes('information'))
      return "La page « Guide Santé » offre des conseils, fiches pratiques et recommandations médicales officielles.";
    if (lower.includes('contact') || lower.includes('support') || lower.includes('aide'))
      return "Pour toute question ou aide technique, rendez-vous sur « Contact & Support » : email, téléphone et formulaire y sont disponibles.";
    if (lower.includes('profil') || lower.includes('paramètre') || lower.includes('compte'))
      return "Gérez vos informations et préférences dans « Profil » ou « Paramètres ». Ici vous pouvez changer la langue, les notifications, etc.";
    if (lower.includes('historique') || lower.includes('antécédent'))
      return "Votre historique médical complet est dans « Historique Médical ». Toutes vos consultations et documents y sont centralisés.";
    if (lower.includes('langue') || lower.includes('néerlandais') || lower.includes('français') || lower.includes('multilingue'))
      return "Vous pouvez passer du français au néerlandais à tout moment via le sélecteur de langue en haut. Toute l’application est traduite !";
    if (lower.includes('sécurité') || lower.includes('confidentiel') || lower.includes('donnée'))
      return "eBox Santé+ protège vos données personnelles avec les normes les plus strictes : chiffrement, authentification forte (Itsme/eID), et contrôle des accès.";
    if (lower.includes('chatbot') || lower.includes('ia') || lower.includes('assistant'))
      return "Je suis l’assistant IA officiel d’eBox Santé+, là pour répondre à vos questions sur la plateforme. Je ne fais pas de diagnostic médical.";
    if (lower.includes('covid'))
      return "Pour toute info Covid-19, consultez www.info-coronavirus.be ou contactez votre médecin.";
    if (lower.includes('merci') || lower.includes('thanks') || lower.includes('sympa'))
      return "Avec plaisir ! Je reste disponible pour toute autre question sur eBox Santé+.";
    if (lower.includes('mobile') || lower.includes('app') || lower.includes('pwa'))
      return "eBox Santé+ est disponible sur mobile et en PWA ! Ajoutez-le à votre écran d’accueil pour un accès rapide et sécurisé.";
    return "Je suis là pour vous aider sur eBox Santé+ ! Essayez par exemple : « Comment partager un document ? », « Changer la langue », « Aide », « Afficher mes analyses »…";
  }

  // Version NL
  getContextualResponseNl(userText: string): string {
    const lower = userText.toLowerCase();

    if (lower.includes('hallo') || lower.includes('goeiedag') || lower.includes('dag'))
      return "Hallo! Hoe kan ik u vandaag begeleiden met eBox Santé+?";
    if (lower.includes('afspraak') || lower.includes('rdv') || lower.includes('rendez-vous'))
      return "Een afspraak maken kan via « Afspraak maken » in het linkermenu. Kies het type, de datum en het uur.";
    if (lower.includes('document') || lower.includes('pdf') || lower.includes('bestand'))
      return "Al uw medische documenten vindt u onder « Mijn Documenten ». U kan ze bekijken, downloaden, delen of een nieuw document uploaden.";
    if (lower.includes('analyse') || lower.includes('onderzoek') || lower.includes('resultaat'))
      return "Uw resultaten van analyses en onderzoeken staan bij « Analyses & Onderzoeken ». Klik voor meer details of om te downloaden als PDF.";
    if (lower.includes('melding') || lower.includes('notificatie') || lower.includes('waarschuwing'))
      return "Uw recente meldingen staan bij het bel-icoontje of op de pagina « Meldingen ». Hier vindt u nieuwe documenten, herinneringen, enz.";
    if (lower.includes('delen') || lower.includes('gedeeld') || lower.includes('verstuur'))
      return "Om een document te delen, ga naar « Mijn Documenten », open het document en klik op « Delen ». U kan ook « Gedeelde Documenten » gebruiken.";
    if (lower.includes('gids') || lower.includes('gezondheid') || lower.includes('informatie'))
      return "De pagina « Gezondheidsgids » biedt officiële tips, praktische fiches en medische aanbevelingen.";
    if (lower.includes('contact') || lower.includes('support') || lower.includes('hulp'))
      return "Voor vragen of technische hulp: ga naar « Contact & Support » voor e-mail, telefoon en contactformulier.";
    if (lower.includes('profiel') || lower.includes('instelling') || lower.includes('account'))
      return "Beheer uw persoonlijke info en voorkeuren bij « Profiel » of « Instellingen ». Hier kan u de taal, meldingen, enz. aanpassen.";
    if (lower.includes('historiek') || lower.includes('voorgeschiedenis'))
      return "Uw volledige medische historiek vindt u onder « Medische Historiek ». Alle consultaties en documenten centraal.";
    if (lower.includes('taal') || lower.includes('nederlands') || lower.includes('frans') || lower.includes('meertalig'))
      return "U kan op elk moment overschakelen tussen Frans en Nederlands via de taalkeuze bovenaan. De hele toepassing is vertaald!";
    if (lower.includes('veilig') || lower.includes('privacy') || lower.includes('gegevens'))
      return "eBox Santé+ beschermt uw persoonlijke gegevens met de strengste normen: encryptie, sterke authenticatie (Itsme/eID), en toegangscontrole.";
    if (lower.includes('chatbot') || lower.includes('ia') || lower.includes('assistent'))
      return "Ik ben de officiële eBox Santé+ assistent, hier om te helpen met al uw platformvragen. Ik stel geen medische diagnoses.";
    if (lower.includes('covid'))
      return "Voor alle info over Covid-19: zie www.info-coronavirus.be of contacteer uw arts.";
    if (lower.includes('bedankt') || lower.includes('dank') || lower.includes('sympa'))
      return "Graag gedaan! Ik ben beschikbaar voor verdere vragen over eBox Santé+.";
    if (lower.includes('mobiel') || lower.includes('app') || lower.includes('pwa'))
      return "eBox Santé+ is beschikbaar op mobiel en als PWA! Voeg toe aan uw startscherm voor snelle en veilige toegang.";
    return "Ik help u graag verder met eBox Santé+! Probeer bijvoorbeeld: « Hoe deel ik een document? », « Taal wijzigen », « Hulp », « Analyses weergeven »…";
  }

  scrollToBottom() {
    const list = document.getElementById('chat-messages');
    if (list) list.scrollTop = list.scrollHeight;
  }
}
