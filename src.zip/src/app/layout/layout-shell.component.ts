import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { SidebarComponent } from './sidebar.component';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-layout-shell',
  standalone: true,
  imports: [CommonModule, RouterOutlet, SidebarComponent, MatIconModule],
  templateUrl: './layout-shell.component.html',
  styleUrls: ['./layout-shell.component.scss']
})
export class LayoutShellComponent {
  currentLang: string;

  constructor(public translate: TranslateService) {
    translate.addLangs(['fr', 'nl']);
    const browserLang = translate.getBrowserLang() || 'fr';
    const savedLang = localStorage.getItem('lang');
    const langToUse = savedLang ?? (['fr', 'nl'].includes(browserLang) ? browserLang : 'fr');
    translate.use(langToUse);
    this.currentLang = langToUse;
  }

  switchLang(lang: string) {
    this.translate.use(lang).subscribe(() => {
      this.currentLang = lang;
      localStorage.setItem('lang', lang);
    });
  }
}
