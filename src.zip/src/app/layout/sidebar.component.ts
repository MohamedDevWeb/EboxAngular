import { Component, Input } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterModule, MatIconModule],
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent {
  @Input() mini = false;
  navLinks = [
  { label: 'Accueil', icon: 'home', route: '/accueil' },        // Ajouté ici
  { label: 'Dashboard', icon: 'dashboard', route: '/dashboard' },
  { label: 'Mes Documents', icon: 'folder_open', route: '/mes-documents' },
  { label: 'Analyses & Examens', icon: 'science', route: '/analyses-examens' },
  { label: 'Prendre RDV', icon: 'event_available', route: '/prendre-rdv' },
  { label: 'Guide Santé', icon: 'local_hospital', route: '/guide' },
  { label: 'Notifications', icon: 'notifications', route: '/notifications' },
  { label: 'Chat IA', icon: 'chat', route: '/chatbot' },
  { label: 'Profil', icon: 'account_circle', route: '/profil' },
  { label: 'Contact', icon: 'support_agent', route: '/contact-support' }
];

  constructor(public router: Router) {}

  logout() {
    localStorage.removeItem('ebox_user');
    window.location.href = '/login';
  }
}
