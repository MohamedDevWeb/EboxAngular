import { Routes } from '@angular/router';

import { LoginComponent } from './pages/login.component';
import { LayoutShellComponent } from './layout/layout-shell.component';

import { DashboardComponent } from './features/dashboard/dashboard.component';
import { MesDocumentsComponent } from './pages/mes-documents.component';
import { ChatbotComponent } from './features/chatbot/chatbot.component';
import { ProfilComponent } from './pages/profil.component';
import { AccueilComponent } from './pages/accueil.component';
import { AnalysesExamensComponent } from './pages/analyses-examens.component';
import { PrendreRdvComponent } from './pages/prendre-rdv.component';

import { AuthGuard } from './auth.guard';

export const appRoutes: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: '',
    component: LayoutShellComponent,
    canActivate: [AuthGuard],
    children: [
      { path: '', redirectTo: 'accueil', pathMatch: 'full' },
      { path: 'dashboard', component: DashboardComponent },
      { path: 'accueil', component: AccueilComponent },
      { path: 'mes-documents', component: MesDocumentsComponent },
      { path: 'analyses-examens', component: AnalysesExamensComponent },
      { path: 'prendre-rdv', component: PrendreRdvComponent },
      { path: 'chatbot', component: ChatbotComponent },
      { path: 'profil', component: ProfilComponent },
      { path: 'guide', loadComponent: () => import('./pages/guide.component').then(m => m.GuideComponent) },
      { path: 'contact-support', loadComponent: () => import('./pages/contact-support.component').then(m => m.ContactSupportComponent) },
      { path: 'notifications', loadComponent: () => import('./pages/notifications.component').then(m => m.NotificationsComponent) },
      { path: 'documents-partages', loadComponent: () => import('./pages/documents-partages.component').then(m => m.DocumentsPartagesComponent) },
      { path: 'parametres', loadComponent: () => import('./pages/parametres.component').then(m => m.ParametresComponent) },
      { path: 'historique', loadComponent: () => import('./pages/historique-medical.component').then(m => m.HistoriqueMedicalComponent) }
    ]
  },
  { path: '**', redirectTo: 'login' }
];
