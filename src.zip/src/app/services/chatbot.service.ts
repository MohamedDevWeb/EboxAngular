import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, map } from 'rxjs';

const HF_API_URL = 'https://api-inference.huggingface.co/models/HuggingFaceH4/zephyr-7b-beta';
const HF_API_KEY = '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'; // Mets ta clé ici

@Injectable({ providedIn: 'root' })
export class ChatbotService {
  constructor(private http: HttpClient) {}

  getAnswer(message: string): Observable<string> {
    const headers = new HttpHeaders({
      'Authorization': `Bearer ${HF_API_KEY}`,
      'Content-Type': 'application/json'
    });

    const body = {
      inputs: {
        past_user_inputs: [],
        generated_responses: [],
        text: message
      },
      parameters: { max_new_tokens: 80 }
    };

    return this.http.post<any>(HF_API_URL, body, { headers }).pipe(
      map(res => {
        if (Array.isArray(res)) {
          return res[0]?.generated_text ?? "Aucune réponse";
        }
        if (res?.generated_text) return res.generated_text;
        if (res?.error) return "❌ Erreur: " + res.error;
        return "❌ Une erreur est survenue.";
      })
    );
  }
}
