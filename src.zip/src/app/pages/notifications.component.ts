import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-notifications',
  standalone: true,
  imports: [CommonModule, MatCardModule, MatIconModule],
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.scss']
})
export class NotificationsComponent {
  notifications = [
    {
      type: 'Rendez-vous confirmé',
      date: '31 juillet 2025',
      message: 'Votre RDV avec Dr. Ait Said est confirmé pour 14h00.',
      icon: 'event_available',
      niveau: 'info'
    },
    {
      type: 'Résultat disponible',
      date: '30 juillet 2025',
      message: 'Vos résultats sanguins sont disponibles.',
      icon: 'science',
      niveau: 'important'
    },
    {
      type: 'Alerte santé',
      date: '28 juillet 2025',
      message: 'Vaccination antigrippale recommandée pour les +65 ans.',
      icon: 'warning',
      niveau: 'critique'
    }
  ];
}
