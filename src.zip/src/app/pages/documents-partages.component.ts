import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-documents-partages',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  templateUrl: './documents-partages.component.html',
  styleUrls: ['./documents-partages.component.scss']
})
export class DocumentsPartagesComponent {
  documents = [
    {
      titre: 'Compte rendu opératoire - Hôpital Saint-Luc',
      source: 'CHU Saint-Luc',
      date: '28 juillet 2025',
      icon: 'upload_file'
    },
    {
      titre: 'Ordonnance envoyée - Maison Médicale Santé+',
      source: 'Dr. Lefèvre',
      date: '25 juillet 2025',
      icon: 'local_pharmacy'
    },
    {
      titre: 'Fiche de vaccination - Vaccin COVID-19',
      source: 'Sciensano',
      date: '20 juillet 2025',
      icon: 'vaccines'
    }
  ];
}
