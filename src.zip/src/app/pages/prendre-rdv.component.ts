// src/app/pages/prendre-rdv.component.ts
import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelectModule } from '@angular/material/select';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';

@Component({
  selector: 'app-prendre-rdv',
  standalone: true,
  templateUrl: './prendre-rdv.component.html',
  styleUrls: ['./prendre-rdv.component.scss'],
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatButtonModule,
    MatDatepickerModule,
    MatNativeDateModule
  ]
})
export class PrendreRdvComponent {
  rdv = {
    medecin: '',
    service: '',
    date: '',
    heure: ''
  };

  validerRdv() {
    alert(`Rendez-vous confirmé avec ${this.rdv.medecin} le ${this.rdv.date} à ${this.rdv.heure}`);
  }
}
