import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-analyses-examens',
  standalone: true,
  imports: [CommonModule, MatCardModule, MatIconModule],
  templateUrl: './analyses-examens.component.html',
  styleUrls: ['./analyses-examens.component.scss']
})
export class AnalysesExamensComponent {
  examens = [
    {
      nom: 'Bilan sanguin complet',
      date: '25 juillet 2025',
      statut: 'Disponible',
      icon: 'science'
    },
    {
      nom: 'Radiographie thoracique',
      date: '22 juillet 2025',
      statut: 'En attente',
      icon: 'radiology'
    },
    {
      nom: 'IRM cérébrale',
      date: '15 juillet 2025',
      statut: 'Disponible',
      icon: 'biotech'
    }
  ];
}
