import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatInputModule } from '@angular/material/input';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-profil',
  standalone: true,
  templateUrl: './profil.component.html',
  styleUrls: ['./profil.component.scss'],
  imports: [
    CommonModule, MatCardModule, MatIconModule, MatButtonModule,
    MatDialogModule, MatInputModule, FormsModule
  ]
})
export class ProfilComponent {
  user = {
    nom: 'Dali',
    email: 'dali@example.com',
    avatar: '',
    itsme: true,
    lastLogin: new Date()
  };

  editing = false;
  editedUser = { ...this.user };

  constructor(public dialog: MatDialog) {}

  openEditDialog() {
    this.editing = true;
    this.editedUser = { ...this.user };
  }

  saveEdit() {
    this.user = { ...this.editedUser };
    this.editing = false;
  }

  cancelEdit() {
    this.editing = false;
  }

  onAvatarChange(event: any) {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e: any) => {
        this.editedUser.avatar = e.target.result;
      };
      reader.readAsDataURL(file);
    }
  }

  simulateItsme() {
    alert("Connexion via Itsme simulée 🚀 (fake UI)");
    this.user.itsme = true;
  }

  logout() {
    window.location.href = '/login';
  }
}
