import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-parametres',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule, MatButtonModule],
  templateUrl: './parametres.component.html',
  styleUrls: ['./parametres.component.scss']
})
export class ParametresComponent {
  user = {
    nom: 'Danielle',
    email: 'danielle@eboxsante.be',
    langue: 'fr'
  };

  languesDisponibles = ['fr', 'nl', 'en'];

  sauvegarder() {
    alert('Paramètres mis à jour avec succès ! ✅');
  }
}
