import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-historique-medical',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  templateUrl: './historique-medical.component.html',
  styleUrls: ['./historique-medical.component.scss']
})
export class HistoriqueMedicalComponent {
  historiques = [
    {
      type: 'consultation',
      icon: 'medical_services',
      titre: 'Consultation – Dr. Dupont',
      description: 'Suivi post-opératoire et mise à jour du traitement.',
      date: '10 juillet 2025'
    },
    {
      type: 'examen',
      icon: 'science',
      titre: 'Analyse sanguine complète',
      description: 'Résultats normaux, pas d’anomalie détectée.',
      date: '05 juillet 2025'
    },
    {
      type: 'vaccin',
      icon: 'vaccines',
      titre: 'Vaccin COVID-19 (rappel)',
      description: 'Injection réalisée au centre médical Louise.',
      date: '28 juin 2025'
    }
  ];
}
