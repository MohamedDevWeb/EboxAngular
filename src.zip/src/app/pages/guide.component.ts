import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-guide',
  standalone: true,
  imports: [CommonModule, MatCardModule, MatIconModule],
  templateUrl: './guide.component.html',
  styleUrls: ['./guide.component.scss']
})
export class GuideComponent {
  guides = [
    {
      title: 'Préparer une consultation',
      icon: 'assignment',
      description: 'Comment bien se préparer avant un rendez-vous médical pour optimiser son temps avec le médecin.'
    },
    {
      title: 'Vaccins recommandés',
      icon: 'vaccines',
      description: 'Découvrez les vaccins essentiels selon votre âge, situation et état de santé.'
    },
    {
      title: 'Urgences : que faire ?',
      icon: 'local_hospital',
      description: 'Identifier les situations d’urgence et les bons réflexes à adopter rapidement.'
    },
    {
      title: 'Santé mentale',
      icon: 'psychology',
      description: 'Conseils pour prendre soin de votre bien-être psychologique au quotidien.'
    },
    {
      title: 'Alimentation & hygiène de vie',
      icon: 'restaurant',
      description: 'Les bases d’un mode de vie sain pour prévenir les maladies chroniques.'
    }
  ];
}
