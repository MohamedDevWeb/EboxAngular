import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, MatIconModule, MatButtonModule],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  loading = false;
  constructor(private router: Router) {}

  login(method: string) {
    this.loading = true;
    setTimeout(() => {
      localStorage.setItem('ebox_user', JSON.stringify({ nom: 'Demo', method }));
      this.router.navigate(['/accueil']);
    }, 900);
  }
}
