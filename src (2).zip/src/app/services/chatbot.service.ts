import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { TranslateService } from '@ngx-translate/core';

@Injectable({ providedIn: 'root' })
export class ChatbotService {
  constructor(private translate: TranslateService) {}

  ask(message: string): Observable<string> {
    const lang = this.translate.currentLang || 'fr';
    const msg = message.toLowerCase();

    if (lang === 'fr') {
      // Exemples de dialogues ultra longs et variés
      if (msg.includes('document') || msg.includes('mes documents'))
        return of(
          "Vous pouvez retrouver <b>tous vos documents médicaux</b> dans la rubrique « Mes Documents ». Utilisez la barre de recherche pour filtrer vos résultats, ou cliquez sur un document pour le visualiser. Besoin d'aide pour télécharger ou partager un document ? Je peux vous guider pas à pas."
        ).pipe(delay(900));

      if (msg.includes('rendez-vous') || msg.includes('rdv'))
        return of(
          "Pour prendre rendez-vous, allez sur la page « Prendre RDV ». Vous pouvez choisir la date, le type de consultation et un médecin. Un email de confirmation vous sera envoyé. N’hésitez pas à demander des détails sur la marche à suivre."
        ).pipe(delay(1300));

      if (msg.includes('analyse') || msg.includes('examen'))
        return of(
          "Les résultats de vos analyses médicales sont dans « Analyses & Examens ». Cliquez sur un résultat pour voir les détails ou téléchargez le PDF. Je peux aussi expliquer comment interpréter vos résultats si besoin."
        ).pipe(delay(1300));

      if (msg.includes('notifi') || msg.includes('alerte'))
        return of(
          "Vous recevez une notification dès qu’un nouveau document ou résultat est ajouté à votre eBox Santé+. Consultez la page « Notifications » pour voir l’historique ou marquer comme lu."
        ).pipe(delay(1000));

      if (msg.includes('contact') || msg.includes('support') || msg.includes('aide'))
        return of(
          "Pour toute question, accédez à la page « Contact & Support » où vous trouverez une FAQ, un formulaire de contact et nos horaires de disponibilité."
        ).pipe(delay(900));

      if (msg.includes('changer mot de passe'))
        return of(
          "Pour changer votre mot de passe, rendez-vous dans la page « Profil », puis cliquez sur « Changer de mot de passe ». Suivez les instructions affichées."
        ).pipe(delay(1000));

      if (msg.includes('bonjour') || msg.includes('salut') || msg.includes('hello'))
        return of(
          "Bonjour 👋 ! Je suis l’assistant eBox Santé+, à votre disposition pour toute question sur vos documents, analyses, RDV ou l’utilisation du site. Posez-moi votre question !"
        ).pipe(delay(800));

      if (msg.includes('merci') || msg.includes('merci beaucoup'))
        return of("Avec plaisir ! 😊 N’hésitez pas si vous avez une autre question.").pipe(delay(700));

      // Réponse par défaut
      return of(
        "Je suis l’assistant eBox Santé+. Posez-moi vos questions sur l’app, les documents, les RDV, la santé ou la sécurité de vos données. Exemple : « Comment télécharger un document ? »"
      ).pipe(delay(1300));
    }

    // Néerlandais
    if (lang === 'nl') {
      if (msg.includes('document'))
        return of(
          "U vindt al uw medische documenten in het gedeelte ‘Mijn documenten’. Gebruik de zoekbalk om te filteren of klik op een document voor details. Hulp nodig met downloaden of delen? Ik help u graag stap voor stap."
        ).pipe(delay(900));

      if (msg.includes('afspraak') || msg.includes('rdv'))
        return of(
          "Voor het maken van een afspraak gaat u naar ‘Afspraak maken’. U kunt datum, consulttype en arts kiezen. Een bevestigingsmail wordt verzonden. Vraag gerust naar de details als u hulp nodig heeft."
        ).pipe(delay(1300));

      if (msg.includes('analyse') || msg.includes('onderzoek'))
        return of(
          "Uw medische resultaten vindt u bij ‘Analyses & Onderzoeken’. Klik op een resultaat voor details of download het PDF. Ik kan ook uitleggen hoe u uw resultaten moet interpreteren."
        ).pipe(delay(1300));

      if (msg.includes('notifi') || msg.includes('melding') || msg.includes('waarschuwing'))
        return of(
          "U ontvangt een melding zodra er een nieuw document of resultaat aan uw eBox Santé+ wordt toegevoegd. Bekijk het overzicht in ‘Meldingen’ en markeer meldingen als gelezen."
        ).pipe(delay(1000));

      if (msg.includes('contact') || msg.includes('support') || msg.includes('hulp'))
        return of(
          "Voor vragen kunt u terecht op de pagina ‘Contact & Support’. Daar vindt u een FAQ, een contactformulier en onze beschikbaarheid."
        ).pipe(delay(900));

      if (msg.includes('wachtwoord'))
        return of(
          "Uw wachtwoord wijzigen? Ga naar ‘Profiel’ en klik op ‘Wachtwoord wijzigen’. Volg de instructies op het scherm."
        ).pipe(delay(1000));

      if (msg.includes('hallo') || msg.includes('dag') || msg.includes('goedemorgen'))
        return of(
          "Hallo 👋 ! Ik ben de eBox Santé+ assistent. Stel gerust al uw vragen over documenten, analyses, afspraken of het gebruik van de website."
        ).pipe(delay(800));

      if (msg.includes('bedankt') || msg.includes('dank'))
        return of("Graag gedaan ! 😊 Stel gerust nog een vraag als u wilt.").pipe(delay(700));

      // Standaard antwoord
      return of(
        "Ik ben de eBox Santé+ assistent. Stel gerust uw vraag over de app, documenten, afspraken, gezondheid of gegevensbescherming. Bijvoorbeeld: ‘Hoe download ik een document?’"
      ).pipe(delay(1300));
    }

    // Fallback autre langue (jamais utilisée car pas EN)
    return of(
      "Merci d’utiliser eBox Santé+. Le chatbot fonctionne en français et néerlandais."
    ).pipe(delay(900));
  }
}
