import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';

import { LanguageSwitcherComponent } from './language-switcher.component';
import { SidebarComponent } from './sidebar.component';

@Component({
  selector: 'app-layout-shell',
  templateUrl: './layout-shell.component.html',
  styleUrls: ['./layout-shell.component.scss'],
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    MatIconModule,
    MatButtonModule,
    LanguageSwitcherComponent,
    SidebarComponent
  ]
})
export class LayoutShellComponent {
  currentYear: number = new Date().getFullYear();
  search: string = '';
  lang: string = localStorage.getItem('lang') || 'fr';

  constructor(private router: Router) {}

  onSearch() {
    if (this.search.trim()) {
      this.router.navigate(['/mes-documents'], { queryParams: { search: this.search } });
      this.search = '';
    }
  }

  logout() {
    localStorage.clear();
    window.location.href = '/login-flux';
  }
}
