import { Component, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { ChatbotService } from '../../services/chatbot.service';

@Component({
  selector: 'app-chatbot',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    FormsModule,
    TranslateModule
  ],
  templateUrl: './chatbot.component.html',
  styleUrls: ['./chatbot.component.scss']
})
export class ChatbotComponent {
  input = '';
  messages: { type: 'user' | 'bot'; text: string }[] = [];
  loading = false;
  lang = 'fr';
  @ViewChild('messagesPanel') messagesPanel?: ElementRef;

  constructor(
    private translate: TranslateService,
    private chatbot: ChatbotService
  ) {
    this.lang = translate.currentLang || translate.defaultLang || 'fr';
    this.translate.onLangChange.subscribe(e => {
      this.lang = e.lang;
      this.messages = [];
      setTimeout(() => {
        this.addBotMessage(
          this.lang === 'fr'
            ? this.greetingMsgFR()
            : this.greetingMsgNL()
        );
      }, 400);
    });

    // Message de bienvenue ultra réaliste selon heure/jour
    setTimeout(() => {
      this.addBotMessage(
        this.lang === 'fr'
          ? this.greetingMsgFR()
          : this.greetingMsgNL()
      );
    }, 400);
  }

  greetingMsgFR(): string {
    const hour = new Date().getHours();
    if (hour < 7)
      return "Bonsoir, je suis l’assistant eBox Santé+ (mode nuit 🌙). Posez-moi vos questions.";
    if (hour < 12)
      return "Bonjour ! Je suis l’assistant eBox Santé+. Posez-moi vos questions sur vos documents, vos RDV, votre santé, ou l’utilisation du site.";
    if (hour < 18)
      return "Bonjour ! Je suis l’assistant eBox Santé+. Comment puis-je vous aider aujourd’hui ?";
    return "Bonsoir ! Je suis l’assistant eBox Santé+. N’hésitez pas à demander toute information santé ou eBox.";
  }

  greetingMsgNL(): string {
    const hour = new Date().getHours();
    if (hour < 7)
      return "Goedenavond, ik ben de eBox Santé+ assistent (nachtmodus 🌙). Stel gerust uw vraag.";
    if (hour < 12)
      return "Goedemorgen! Ik ben de eBox Santé+ assistent. Stel hier uw vragen over documenten, afspraken of gezondheid.";
    if (hour < 18)
      return "Hallo! Ik ben de eBox Santé+ assistent. Waarmee kan ik u vandaag helpen?";
    return "Goedenavond! Ik ben de eBox Santé+ assistent. Aarzel niet om alles te vragen over gezondheid of eBox.";
  }

  sendMessage() {
    if (!this.input.trim()) return;
    const userMsg = this.input;
    this.addUserMessage(userMsg);
    this.input = '';
    this.loading = true;

    setTimeout(() => this.scrollToBottom(), 1);

    this.chatbot.ask(userMsg).subscribe(botReply => {
      this.addBotMessage(botReply);
      this.loading = false;
      setTimeout(() => this.scrollToBottom(), 50);
    });
  }

  quickMsg(msg: string) {
    this.input = msg;
    setTimeout(() => this.sendMessage(), 100);
  }

  addUserMessage(msg: string) {
    this.messages.push({ type: 'user', text: msg });
    setTimeout(() => this.scrollToBottom(), 20);
  }
  addBotMessage(msg: string) {
    this.messages.push({ type: 'bot', text: msg });
    setTimeout(() => this.scrollToBottom(), 20);
  }

  scrollToBottom() {
    if (this.messagesPanel) {
      try {
        this.messagesPanel.nativeElement.scrollTop = this.messagesPanel.nativeElement.scrollHeight;
      } catch { }
    }
  }
}
