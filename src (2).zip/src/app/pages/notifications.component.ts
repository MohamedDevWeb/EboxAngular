import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-notifications',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatIconModule,
    TranslateModule
  ],
  templateUrl: './notifications.component.html',
  styleUrls: ['./notifications.component.scss']
})
export class NotificationsComponent {
  notifications = [
    {
      title: 'Nouveau document disponible',
      desc: 'Une nouvelle prescription a été ajoutée à vos documents.',
      date: '02/08/2025',
      icon: 'description',
      type: 'info'
    },
    {
      title: 'Rappel de rendez-vous',
      desc: 'Vous avez un rendez-vous médical le 12/08/2025 à 09:30.',
      date: '01/08/2025',
      icon: 'event_available',
      type: 'rdv'
    },
    {
      title: 'Nouveau résultat d’analyse',
      desc: 'Vos résultats de prise de sang du 10/07/2025 sont disponibles.',
      date: '25/07/2025',
      icon: 'science',
      type: 'result'
    }
  ];
}
