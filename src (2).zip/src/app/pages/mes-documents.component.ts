import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';  // <-- AJOUTE MOI !
import { MatIconModule } from '@angular/material/icon';

interface DocumentFake {
  id: number;
  nom: string;
  type: string;
  date: string;
  url: string;
}

@Component({
  selector: 'app-mes-documents',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule], // <--- AJOUTE FormsModule ICI !
  templateUrl: './mes-documents.component.html',
  styleUrls: ['./mes-documents.component.scss']
})
export class MesDocumentsComponent {
  lang = localStorage.getItem('lang') || 'fr';
  recherche = '';
  modalOuvert = false;
  nouveauNom = '';
  nouveauType = '';
  fichiers: DocumentFake[] = [
    { id: 1, nom: "Résultat Covid.pdf", type: "Analyse", date: "2024-07-08", url: "/assets/fake-pdf.pdf" },
    { id: 2, nom: "Ordonnance_2024.pdf", type: "Prescription", date: "2024-05-17", url: "/assets/fake-pdf.pdf" }
  ];
  nextId = 3;

  get t() {
    return this.lang === 'nl' ? this.translations.nl : this.translations.fr;
  }
  translations = {
    fr: {
      titre: "Mes documents",
      boutonAjouter: "Ajouter un document",
      placeholderRecherche: "Rechercher un document…",
      type: "Type",
      nom: "Nom",
      date: "Date",
      actions: "Actions",
      telecharger: "Télécharger",
      aucun: "Aucun document trouvé",
      modalTitre: "Ajouter un document",
      modalNom: "Nom du document",
      modalType: "Type de document",
      modalCharger: "Charger le fichier",
      modalValider: "Ajouter",
      modalAnnuler: "Annuler"
    },
    nl: {
      titre: "Mijn documenten",
      boutonAjouter: "Document toevoegen",
      placeholderRecherche: "Zoek een document…",
      type: "Type",
      nom: "Naam",
      date: "Datum",
      actions: "Acties",
      telecharger: "Downloaden",
      aucun: "Geen documenten gevonden",
      modalTitre: "Document toevoegen",
      modalNom: "Documentnaam",
      modalType: "Documenttype",
      modalCharger: "Bestand uploaden",
      modalValider: "Toevoegen",
      modalAnnuler: "Annuleren"
    }
  };

  ouvrirModal() {
    this.modalOuvert = true;
    this.nouveauNom = '';
    this.nouveauType = '';
  }

  fermerModal() {
    this.modalOuvert = false;
  }

  ajouterDocument(event: any) {
    event.preventDefault();
    if (this.nouveauNom && this.nouveauType) {
      this.fichiers.unshift({
        id: this.nextId++,
        nom: this.nouveauNom,
        type: this.nouveauType,
        date: new Date().toISOString().slice(0, 10),
        url: '/assets/fake-pdf.pdf'
      });
      this.fermerModal();
    }
  }

  rechercheDocuments() {
    const q = this.recherche.trim().toLowerCase();
    if (!q) return this.fichiers;
    return this.fichiers.filter(d =>
      d.nom.toLowerCase().includes(q) ||
      d.type.toLowerCase().includes(q)
    );
  }

  setLang(lang: 'fr' | 'nl') {
    this.lang = lang;
    localStorage.setItem('lang', lang);
  }
}
