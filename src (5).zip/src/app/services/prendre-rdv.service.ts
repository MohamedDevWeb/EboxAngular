import { Injectable } from '@angular/core';
import { Observable, of, delay } from 'rxjs';

export interface Medecin {
  id: number;
  nom: string;
  specialite: string;
}
export interface MotifItem {
  id: number;
  nom: string;
}
export interface RdvItem {
  id: number;
  medecin: Medecin;
  motif: MotifItem;
  date: Date;
  creneau: string;
  commentaire?: string;
  pieceJointe?: string | null;
}
@Injectable({ providedIn: 'root' })
export class PrendreRdvService {
  private medecins: Medecin[] = [
    { id: 1, nom: "Dupont", specialite: "Généraliste" },
    { id: 2, nom: "Martin", specialite: "Cardiologue" },
    { id: 3, nom: "Durand", specialite: "Pédiatre" },
    { id: 4, nom: "Mehdi", specialite: "Dermatologue" }
  ];
  private motifs: MotifItem[] = [
    { id: 1, nom: "Consultation générale" },
    { id: 2, nom: "Renouvellement ordonnance" },
    { id: 3, nom: "Résultats analyse" },
    { id: 4, nom: "Suivi traitement" },
    { id: 5, nom: "Urgence légère" }
  ];
  private creneauxDefaut: string[] = [
    "09:00", "09:30", "10:00", "10:30",
    "11:00", "11:30", "14:00", "14:30",
    "15:00", "15:30", "16:00"
  ];
  getMedecins(): Observable<Medecin[]> {
    return of(this.medecins).pipe(delay(350));
  }
  getMotifs(): MotifItem[] {
    return this.motifs;
  }
  getCreneaux(medecinId: number, date: Date): Observable<string[]> {
    // Simule un planning plus ou moins chargé
    let slots = [...this.creneauxDefaut];
    // Random: simule indispo (juste pour la démo)
    if (date.getDay() === 0 || date.getDay() === 6) slots = []; // Pas de créneaux week-end
    if (medecinId % 2 === 0 && slots.length > 0) slots = slots.filter((_, i) => i % 2 === 0);
    if (Math.random() > 0.8) slots = slots.slice(0, Math.floor(Math.random() * slots.length));
    return of(slots).pipe(delay(500));
  }
  prendreRdv(item: RdvItem): Observable<any> {
    // Simule un POST vers l’API
    return of({ success: true }).pipe(delay(1200));
  }
}
