import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { FormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';

@Component({
  selector: 'app-prendre-rdv',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatDatepickerModule,
    MatButtonModule,
    MatIconModule,
    FormsModule,
    TranslateModule
  ],
  templateUrl: './prendre-rdv.component.html',
  styleUrls: ['./prendre-rdv.component.scss']
})
export class PrendreRdvComponent {
  rdv = {
    type: '',
    date: '',
    heure: '',
    motif: ''
  };
  types = ['Médecin généraliste', 'Spécialiste', 'Examen médical', 'Vaccination'];
  heures = [
    '08:00', '08:30', '09:00', '09:30', '10:00',
    '10:30', '11:00', '11:30', '12:00', '14:00',
    '14:30', '15:00', '15:30', '16:00', '16:30'
  ];
  submitted = false;

  submit() {
    this.submitted = true;
    setTimeout(() => this.submitted = false, 2500);
    // Ici tu peux ajouter la logique d’envoi à une API...
  }
}
