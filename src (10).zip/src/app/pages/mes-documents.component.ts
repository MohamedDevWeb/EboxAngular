import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { FormsModule } from '@angular/forms';

interface DocumentEntry {
  type: string;
  titre: string;
  date: string;
  etat: 'validé' | 'en attente' | 'expiré';
  telechargement?: string; // url ou base64, ici pour la maquette c'est une icône
}

@Component({
  selector: 'app-mes-documents',
  standalone: true,
  imports: [CommonModule, MatIconModule, MatButtonModule, FormsModule],
  templateUrl: './mes-documents.component.html',
  styleUrls: ['./mes-documents.component.scss']
})
export class MesDocumentsComponent {
  lang: 'fr' | 'nl' = localStorage.getItem('lang') as 'fr' | 'nl' || 'fr';

  documents: DocumentEntry[] = [
    {
      type: 'Ordonnance',
      titre: 'Ordonnance renouvellement traitement',
      date: '12/07/2025',
      etat: 'validé',
      telechargement: '#'
    },
    {
      type: 'Attestation',
      titre: 'Attestation de soins INAMI',
      date: '10/07/2025',
      etat: 'validé',
      telechargement: '#'
    },
    {
      type: 'Résultat',
      titre: 'Résultat test sanguin',
      date: '01/07/2025',
      etat: 'en attente'
    },
    {
      type: 'Vaccination',
      titre: 'Certificat COVID',
      date: '20/06/2025',
      etat: 'expiré'
    }
  ];

  filter = '';
  get filteredDocs() {
    return this.documents.filter(d =>
      (d.titre + d.type).toLowerCase().includes(this.filter.toLowerCase())
    );
  }

  download(doc: DocumentEntry) {
    alert(this.lang === 'fr'
      ? `Téléchargement de "${doc.titre}"`
      : `Downloaden van "${doc.titre}"`);
    // Ajoute ici la vraie logique de téléchargement plus tard
  }
}
