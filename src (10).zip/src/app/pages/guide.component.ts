import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { TranslateModule, TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-guide',
  standalone: true,
  imports: [CommonModule, MatCardModule, MatIconModule, TranslateModule],
  templateUrl: './guide.component.html',
  styleUrls: ['./guide.component.scss']
})
export class GuideComponent {
  lang = 'fr';
  guides = [
    {
      icon: 'info',
      titreFr: "Consulter vos résultats médicaux",
      titreNl: "Uw medische resultaten raadplegen",
      descFr: "Rendez-vous dans « Mes Documents » ou « Analyses & Examens ». Cliquez sur l’icône œil pour lire ou télécharger chaque résultat.",
      descNl: "Ga naar ‘Mijn documenten’ of ‘Analyses & Onderzoeken’. Klik op het oog-icoon om uw resultaten te bekijken of te downloaden."
    },
    {
      icon: 'lock',
      titreFr: "Sécurité de vos données",
      titreNl: "Veiligheid van uw gegevens",
      descFr: "Vos données sont protégées et accessibles uniquement via votre identification sécurisée (eID/itsme).",
      descNl: "Uw gegevens zijn beschermd en alleen toegankelijk via uw beveiligde identificatie (eID/itsme)."
    },
    {
      icon: 'local_hospital',
      titreFr: "Questions santé courantes",
      titreNl: "Veelgestelde gezondheidsvragen",
      descFr: "Notre section FAQ répond aux questions les plus fréquentes concernant la santé et la gestion de vos documents.",
      descNl: "Onze FAQ-sectie beantwoordt de meest gestelde vragen over gezondheid en documentbeheer."
    }
  ];

  constructor(private translate: TranslateService) {
    this.lang = translate.currentLang || translate.defaultLang || 'fr';
    this.translate.onLangChange.subscribe(e => { this.lang = e.lang; });
  }
}
